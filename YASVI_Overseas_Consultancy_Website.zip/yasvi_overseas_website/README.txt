YASVI Overseas Consultancy website
==================================

Files:
- index.html: Website content
- styles.css: Responsive design and styling
- script.js: Mobile menu and enquiry email form
- favicon.svg: Browser tab icon

Preview locally:
1. Extract the ZIP.
2. Double-click index.html to open it in a browser.
3. Internet is needed for the Google Fonts; the rest of the page is local.

Publish free with GitHub Pages:
1. Create/sign in to a GitHub account at https://github.com/
2. Create a NEW PUBLIC repository named: yasvi-overseas-website
3. Upload index.html, styles.css, script.js, and favicon.svg to the repository root.
4. Open repository Settings > Pages.
5. Under Build and deployment, choose "Deploy from a branch".
6. Select branch "main" and folder "/ (root)", then Save.
7. Wait for the published link to appear on the Pages settings page.

Your site will use a URL similar to:
https://YOUR-GITHUB-USERNAME.github.io/yasvi-overseas-website/

Important:
- Replace YOUR-GITHUB-USERNAME with your actual GitHub username; don't type the example URL as your final address.
- The enquiry form opens the visitor's email app; it does not store form submissions. WhatsApp and phone buttons work through the provided contact number.
- A custom domain is optional and usually costs extra.
- Before publishing, verify all contact details and address spelling.
